# @clickpay/sdk

SDK oficial da **ClickPay** para JavaScript e TypeScript.

Integre pagamentos PIX, gestão de clientes, produtos, webhooks e saques em qualquer ambiente JS — Node.js, NestJS, Next.js, browser e mais.

## Instalação

```bash
npm install @clickpay/sdk
# ou
yarn add @clickpay/sdk
# ou
pnpm add @clickpay/sdk
```

## Quick Start

```ts
import { ClickPay, WebhookEvent } from '@clickpay/sdk';

const clickpay = new ClickPay({
  apiKey: 'pk_live_sua_chave_aqui',
});
```

## Cobranças (Charges)

### Criar link de pagamento

```ts
const charge = await clickpay.charges.createPaymentLink({
  total: 5000, // R$ 50,00 (em centavos)
  customer: {
    taxId: '12345678900',
    name: 'João Silva',
    email: 'joao@email.com',
    phone: '11999999999',
  },
  successUrl: 'https://meusite.com/sucesso',
  failedUrl: 'https://meusite.com/falha',
  items: [
    { productId: 'prod_abc123', quantity: 2 },
  ],
});

console.log(charge.data?.url); // URL da página de pagamento
```

### Criar cobrança PIX direta

```ts
const pix = await clickpay.charges.createPixCharge({
  amount: 1500, // R$ 15,00
  customer: {
    taxId: '12345678900',
    name: 'Maria Santos',
    email: 'maria@email.com',
    phone: '11988888888',
  },
  expiresIn: 900, // 15 minutos
});

console.log(pix.data?.brCode);       // PIX copia-e-cola
console.log(pix.data?.brCodeBase64); // QR Code em base64
```

### Consultar cobrança

```ts
const charge = await clickpay.charges.getById('charge_id_aqui');

console.log(charge.data?.status);        // OPEN | COMPLETED | EXPIRED
console.log(charge.data?.paymentStatus); // PENDING | PROCESSING | PAID | EXPIRED
```

### Gerar PIX para link de pagamento existente

```ts
const pixPayment = await clickpay.charges.generatePixForCharge('charge_id', {
  customer: {
    taxId: '12345678900',
    name: 'João Silva',
    email: 'joao@email.com',
    phone: '11999999999',
  },
});
```

### Simular pagamento (sandbox)

```ts
// Funciona apenas com cobranças criadas com devMode: true
await clickpay.charges.simulatePayment('charge_id');
```

### Idempotência

As operações de criação de cobrança suportam chave de idempotência (UUID v4, TTL 24h):

```ts
const charge = await clickpay.charges.createPixCharge(
  { amount: 5000, customer: { /* ... */ } },
  { idempotencyKey: 'f47ac10b-58cc-4372-a567-0e02b2c3d479' },
);
```

## Clientes (Customers)

```ts
import { DefaultStatus } from '@clickpay/sdk';

// Listar todos
const customers = await clickpay.customers.list();

// Buscar por ID
const customer = await clickpay.customers.getById('cust_abc123');

// Criar cliente
const newCustomer = await clickpay.customers.create({
  name: 'João Silva',
  taxId: '12345678900',
  email: 'joao@email.com',
  phone: '11999999999',
  status: DefaultStatus.ACTIVE,
  postalCode: '01001000',
  address: 'Praça da Sé',
  number: '1',
  district: 'Sé',
});

// Atualizar cliente
await clickpay.customers.update({
  id: 'cust_abc123',
  phone: '11977777777',
  status: DefaultStatus.INACTIVE,
});
```

## Produtos (Products)

```ts
// Listar produtos
const products = await clickpay.products.list({ status: DefaultStatus.ACTIVE });

// Buscar por ID
const product = await clickpay.products.getById('prod_abc123');

// Buscar por SKU
const product = await clickpay.products.getBySku('PLAN-MONTHLY');

// Criar produto
const newProduct = await clickpay.products.create({
  name: 'Plano Mensal',
  description: 'Assinatura mensal do serviço',
  price: 4990, // R$ 49,90 (em centavos)
  sku: 'PLAN-MONTHLY',
});

// Atualizar produto
await clickpay.products.update({
  id: 'prod_abc123',
  price: 5990,
});
```

## Webhooks

```ts
import { WebhookEvent } from '@clickpay/sdk';

// Listar webhooks
const webhooks = await clickpay.webhooks.list();

// Criar webhook
const webhook = await clickpay.webhooks.create({
  name: 'Meu Webhook',
  url: 'https://meusite.com/webhooks/clickpay',
  events: [WebhookEvent.CHARGE_PAID, WebhookEvent.CHARGE_EXPIRED],
});

// Atualizar webhook
await clickpay.webhooks.update({
  id: 'wh_abc123',
  events: [WebhookEvent.CHARGE_PAID],
});

// Deletar webhook
await clickpay.webhooks.delete('wh_abc123');

// Listar eventos disponíveis
const events = await clickpay.webhooks.listEvents();

// Estatísticas da fila
const stats = await clickpay.webhooks.getQueueStats();
```

## Conta (Account)

```ts
// Consultar saldo
const balance = await clickpay.account.getBalance();

// Criar saque (transferência PIX)
const withdraw = await clickpay.account.withdraw({
  value: 10000, // R$ 100,00
});

// Listar histórico de saques
const withdrawals = await clickpay.account.listWithdrawals();
```

## Configuração Avançada

### Opções do cliente

```ts
const clickpay = new ClickPay({
  // Autenticação (obrigatório: apiKey OU accessToken)
  apiKey: 'pk_live_...',

  // URL customizada (padrão: https://api.clickpay.app.br)
  baseUrl: 'https://minha-api.com',

  // Ambiente sandbox
  sandbox: true,

  // Timeout em ms (padrão: 30000)
  timeout: 15000,

  // Retentativas automáticas em 429/5xx (padrão: 2)
  maxRetries: 3,

  // Headers extras
  headers: {
    'X-Custom-Header': 'valor',
  },

  // fetch customizado (Node.js < 18)
  fetch: customFetchImplementation,
});
```

### Tratamento de erros

```ts
import {
  ClickPay,
  ClickPayApiError,
  ClickPayRateLimitError,
  ClickPayIdempotencyError,
  ClickPayTimeoutError,
  ClickPayNetworkError,
} from '@clickpay/sdk';

try {
  await clickpay.charges.createPixCharge({ /* ... */ });
} catch (error) {
  if (error instanceof ClickPayRateLimitError) {
    console.log(`Rate limited. Retry in ${error.retryAfter}s`);
  } else if (error instanceof ClickPayIdempotencyError) {
    console.log('Idempotency key conflict');
  } else if (error instanceof ClickPayTimeoutError) {
    console.log('Request timed out');
  } else if (error instanceof ClickPayNetworkError) {
    console.log('Network error:', error.message);
  } else if (error instanceof ClickPayApiError) {
    console.log(`API error ${error.statusCode}: ${error.message}`);
    console.log('Response body:', error.body);
  }
}
```

## Uso com NestJS

```ts
import { Module } from '@nestjs/common';
import { ClickPay } from '@clickpay/sdk';

@Module({
  providers: [
    {
      provide: ClickPay,
      useFactory: () =>
        new ClickPay({ apiKey: process.env.CLICKPAY_API_KEY }),
    },
  ],
  exports: [ClickPay],
})
export class ClickPayModule {}

// No service:
@Injectable()
export class PaymentService {
  constructor(private readonly clickpay: ClickPay) {}

  async createCharge(amount: number) {
    return this.clickpay.charges.createPixCharge({
      amount,
      customer: { /* ... */ },
    });
  }
}
```

## Valores monetários

Todos os valores monetários na SDK são representados em **centavos** (inteiros):

| Valor real | Valor na SDK |
|-----------|-------------|
| R$ 5,00   | `500`       |
| R$ 49,90  | `4990`      |
| R$ 100,00 | `10000`     |

O valor mínimo para cobranças é **500** (R$ 5,00).

## Tipos e Enums

Todos os tipos TypeScript são exportados para uso direto:

```ts
import type {
  Customer,
  CreateCustomerInput,
  ChargeDetail,
  CreatePixChargeInput,
  Product,
  Webhook,
  ClickPayResponse,
} from '@clickpay/sdk';

import {
  DefaultStatus,
  ChargeStatus,
  PaymentStatus,
  WebhookEvent,
  WithdrawStatus,
} from '@clickpay/sdk';
```

## Compatibilidade

| Ambiente        | Suportado |
|----------------|-----------|
| Node.js ≥ 18   | ✅        |
| Bun            | ✅        |
| Deno            | ✅        |
| Browser (ESM)  | ✅        |
| NestJS         | ✅        |
| Next.js        | ✅        |
| React Native   | ✅        |

> Para Node.js < 18, passe uma implementação de `fetch` via a opção `fetch` (ex: `node-fetch` ou `undici`).

## Licença

MIT
